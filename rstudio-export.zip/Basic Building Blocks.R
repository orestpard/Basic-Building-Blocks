install.packages("swirl")
library(swirl)
install_from_swirl("R Programming")
